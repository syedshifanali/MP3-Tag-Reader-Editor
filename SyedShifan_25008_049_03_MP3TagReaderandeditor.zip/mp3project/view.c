
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "types.h"
#include "view.h"
#include "edit.h"

/* Function to display the tags of the MP3 file.
 * It reads the tags from the MP3 file and prints them to the console.
 * Returns e_success on successful display, e_failure otherwise.
 */

Status store_tags_v2(MP_READ *mp3_reader)
{
    // Use a struct array to simplify tag reading
    struct TagInfo {
        char *tag;
        int *size;
        char *name;
    } tags[] = {
        {mp3_reader->title_tag, &mp3_reader->title_size, mp3_reader->title_name},
        {mp3_reader->artist_tag, &mp3_reader->artist_size, mp3_reader->artist_name},
        {mp3_reader->album_tag, &mp3_reader->album_size, mp3_reader->album_name},
        {mp3_reader->Year_tag, &mp3_reader->Year_size, mp3_reader->Year},
        {mp3_reader->Content_tag, &mp3_reader->Content_size, mp3_reader->Content_type},
        {mp3_reader->Comment_tag, &mp3_reader->Comment_size, mp3_reader->Comment}
    };
    for (int i = 0; i < 6; i++) {
        mp3_reader->tag_pos[i] = ftell(mp3_reader->fptr_mp3);
    strcpy(tags[i].tag, tag_read_v2(mp3_reader->fptr_mp3));
    *(tags[i].size) = size_read_v2(mp3_reader->fptr_mp3);
    strcpy(tags[i].name, name_read_v2(mp3_reader->fptr_mp3, *(tags[i].size)));
    }
    return e_success;
}

/* Function to print help instructions.
 * It displays the usage and available operations for the MP3 tag reader and editor.
 */

void Print() 
{
    printf("ERROR: ./a.out – Invalid arguments.\n");
    printf("Usage: \n");
    printf("To display, use the following format: ./a.out -v mp3filename\n");
    printf("To edit, pass arguments as follows: ./a.out -e -t/-a/-A/-m/-y/-c changing_text mp3filename\n");
    printf("To get help, use the following format: ./a.out --help\n");
}


/* open_files function to open the MP3 file for reading.
 * It initializes the file pointer and checks if the file exists.
 * Returns e_success on successful opening, e_failure otherwise.
 */

Status open_files_v2(MP_READ *mp3_reader)
{
    mp3_reader->fptr_mp3 = fopen(mp3_reader->file_name, "r");
    if (mp3_reader->fptr_mp3 == NULL) {
        perror("fopen");
        fprintf(stderr, "ERROR: Opening file %s failed.\n", mp3_reader->file_name);
        return e_failure;
    }
    return e_success;
}

/* Function to read the general tag from the MP3 file.
 * It reads the tag and returns it as a string.
 * Returns the tag string on success, NULL on failure.
 */


// Simpler tag_read: just return a static buffer
char* tag_read_v2(FILE *fptr_mp3)
{
    static char tag_buffer[5];
    fread(tag_buffer, 4, 1, fptr_mp3);
    tag_buffer[4] = '\0';
    return tag_buffer;
}


/* Function to read the size of the tag from the MP3 file.
 * It reads 4 bytes and returns the size as an integer.
 * Returns the size on success, -1 on failure.
 */


// Simpler size_read: just read and swap
int size_read_v2(FILE *fptr_mp3)
{
    int size_buffer = 0;
    fread(&size_buffer, 4, 1, fptr_mp3);
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    size_buffer = ((size_buffer>>24)&0xff) | // move byte 3 to byte 0
                  ((size_buffer<<8)&0xff0000) | // move byte 1 to byte 2
                  ((size_buffer>>8)&0xff00) | // move byte 2 to byte 1
                  ((size_buffer<<24)&0xff000000); // move byte 0 to byte 3
#endif
    return size_buffer;
}

/* Function to read the name associated with the tag from the MP3 file.
 * It reads the name based on the size provided and returns it as a string.
 * Returns the name string on success, NULL on failure.
 */


// Simpler name_read: just return a static buffer
char *name_read_v2(FILE *fptr_mp3, int size)
{
    static char name_buffer[256];
    fseek(fptr_mp3, 3, SEEK_CUR);
    fread(name_buffer, 1, size - 1, fptr_mp3);
    name_buffer[size - 1] = '\0';
    return name_buffer;
}